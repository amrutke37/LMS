﻿CREATE TABLE books
(
	[accNo] INT NOT NULL PRIMARY KEY, 
    [isbn] VARCHAR(10) NULL, 
    [name] VARCHAR(10) NULL, 
    [author] VARCHAR(10) NULL, 
    [publisher] VARCHAR(10) NULL, 
    [dId] INT NULL, 
    [borrower] INT NULL, 
    CONSTRAINT [FK_books_ToTable] FOREIGN KEY (dId) REFERENCES department(dep_id), 
    CONSTRAINT [FK_books_ToTable_1] FOREIGN KEY (borrower) REFERENCES borrowers(brId), 
    
)
